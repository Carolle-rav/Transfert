import fenetre.Fenetre;

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");
        Fenetre fenetre_client = new Fenetre();
    }
}
