import front.Fenetre;
import transfert.Client_socket;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class App {
    public static void main(String[] args) {
        final String[] savePath = {""}; // Utilisation d'un tableau mutable pour stocker le chemin

        // Créer le JFrame pour la configuration
        JFrame frame = new JFrame("Configuration");
        frame.setSize(400, 250);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        // Créer les composants
        JPanel panel = new JPanel(new GridLayout(4, 2, 10, 10));
        JLabel ipLabel = new JLabel("IP du serveur :");
        JTextField ipField = new JTextField("172.0.0.5"); // Valeur par défaut
        JLabel portLabel = new JLabel("Port de connexion :");
        JTextField portField = new JTextField("12345"); // Valeur par défaut
        JLabel pathLabel = new JLabel("Chemin de sauvegarde :");
        JTextField pathField = new JTextField(); // Champ texte pour afficher le chemin
        pathField.setEditable(false); // Le champ n'est pas modifiable directement par l'utilisateur
        JButton browseButton = new JButton("Parcourir...");
        JButton connectButton = new JButton("Se connecter");

        // Ajouter les composants au panel
        panel.add(ipLabel);
        panel.add(ipField);
        panel.add(portLabel);
        panel.add(portField);
        panel.add(pathLabel);
        panel.add(pathField);
        panel.add(browseButton);
        panel.add(connectButton);

        frame.add(panel, BorderLayout.CENTER);

        // Action pour le bouton "Parcourir..."
        browseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser directoryChooser = new JFileChooser();
                directoryChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY); // Limiter au choix des répertoires
                int result = directoryChooser.showOpenDialog(frame);
                if (result == JFileChooser.APPROVE_OPTION) {
                    savePath[0] = directoryChooser.getSelectedFile().getAbsolutePath();
                    pathField.setText(savePath[0]); // Afficher le chemin dans le champ texte
                }
            }
        });

        // Action pour le bouton "Se connecter"
        connectButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String ip = ipField.getText();
                String portText = portField.getText();

                if (savePath[0].isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Veuillez choisir un chemin de sauvegarde.", "Erreur", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                try {

                    // Créer le client socket
                    Client_socket client = new Client_socket(portText, ip);
                    client.setSave_path(savePath[0]);

                    // Ouvrir la fenêtre principale
                    Fenetre fenster = new Fenetre();
                    fenster.setClient_socket(client);

                    // Fermer la fenêtre de configuration
                    frame.dispose();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Le port doit être un nombre valide.", "Erreur", JOptionPane.ERROR_MESSAGE);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(frame, "Erreur : " + ex.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Afficher la fenêtre
        frame.setVisible(true);
    }
}
